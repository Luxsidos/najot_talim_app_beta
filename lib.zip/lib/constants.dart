import 'package:flutter/material.dart';

var kPrimaryColor = Color(0xFF0F1826);
var kPrimaryLightColor = Color(0xFFAE8D5E);
var kPrimaryTextColor = Colors.white;
var kPrimarySubtitleColor = Colors.grey.shade400;
